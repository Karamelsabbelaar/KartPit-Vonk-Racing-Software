# KartPit — Supabase Auth Setup

## 1. Supabase project aanmaken
Ga naar https://supabase.com en maak een nieuw project aan.

---

## 2. Profiles tabel aanmaken
Voer dit uit in de **SQL Editor** van Supabase:

```sql
-- Profiles tabel (uitbreiding op auth.users)
create table public.profiles (
  id          uuid primary key references auth.users(id) on delete cascade,
  email       text,
  full_name   text,
  role        text not null default 'user' check (role in ('admin', 'user')),
  created_at  timestamptz default now()
);

-- Row Level Security inschakelen
alter table public.profiles enable row level security;

-- Beleid: ingelogde gebruikers mogen hun eigen profiel lezen
create policy "Eigen profiel lezen"
  on public.profiles for select
  using (auth.uid() = id);

-- Beleid: admins mogen alle profielen lezen
create policy "Admin leest alle profielen"
  on public.profiles for select
  using (
    exists (
      select 1 from public.profiles
      where id = auth.uid() and role = 'admin'
    )
  );

-- Beleid: alleen service role mag invoegen/verwijderen (via Admin API)
create policy "Service role mag alles"
  on public.profiles for all
  using (auth.role() = 'service_role');
```

---

## 3. Eerste admin account aanmaken
Maak handmatig het eerste admin account aan via de Supabase dashboard:

1. Ga naar **Authentication → Users → Add user**
2. Vul e-mail en wachtwoord in
3. Ga naar **Table Editor → profiles**
4. Voeg een rij in met:
   - `id`: UUID van de zojuist aangemaakte user
   - `email`: e-mailadres
   - `full_name`: naam
   - `role`: `admin`

---

## 4. Config instellen
Vul in zowel `login.html` als `admin.html` je gegevens in:

```js
const SUPABASE_URL        = 'https://jouw-project.supabase.co';
const SUPABASE_ANON       = 'jouw-anon-public-key';       // Veilig voor front-end
const SUPABASE_SERVICE_KEY = 'jouw-service-role-key';     // Zie opmerking hieronder
```

Je vindt deze sleutels via: **Project Settings → API**

---

## ⚠️ Belangrijk: Service Role Key
De `service_role` key heeft volledige toegang tot je database en mag nooit
publiek zichtbaar zijn in een productie-omgeving.

**Voor productie**: verplaats het aanmaken/verwijderen van accounts naar een
Supabase **Edge Function**, zodat de service key server-side blijft.

**Voor prototype/intern gebruik**: de huidige aanpak (key in front-end) is
acceptabel als de admin.html pagina alleen intern bereikbaar is.

---

## 5. Bestanden
| Bestand      | Doel                                      |
|--------------|-------------------------------------------|
| `login.html` | Inlogpagina voor alle gebruikers          |
| `admin.html` | Accountbeheer (alleen toegankelijk admin) |
| `auth.js`    | Herbruikbare auth helpers (optioneel)     |

---

## 6. Beveiliging samenvatting
- Niet-ingelogde gebruikers worden doorgestuurd naar `login.html`
- Ingelogde niet-admins worden doorgestuurd naar `index.html`
- Alleen admins bereiken `admin.html`
- Row Level Security beschermt de database direct
